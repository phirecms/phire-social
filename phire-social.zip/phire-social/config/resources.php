<?php

return [
    'social' => [
        'index'
    ]
];